
public class FSMState {

	public String str;
	
    public FSMState(){
    }

    public FSMState(String str){
    	this.str = str;
    }
    
}
