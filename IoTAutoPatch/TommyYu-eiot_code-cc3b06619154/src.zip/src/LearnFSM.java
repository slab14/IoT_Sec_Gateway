import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class LearnFSM {

	public static MealyFSM buildTreeFSM( ArrayList<String[][]> traces ){
		
		MealyFSM treeFSM = new MealyFSM();
		// add s0
		treeFSM.initialStateStr = treeFSM.newState();
		
		for (int m = 0; m < traces.size(); m++)
		{
			treeFSM.curStateStr = treeFSM.initialStateStr;
			
			for (int j = 0; j < traces.get(m).length; j++)
			{
				if ( treeFSM.lambda.get(treeFSM.curStateStr) == null ){
					
					String nextStateStr = treeFSM.newState();
					
					Map<String, String> dmap = new HashMap<String,String>();
					dmap.put(traces.get(m)[j][0], nextStateStr);
					treeFSM.delta.put(treeFSM.curStateStr, dmap);		
					
					Map<String, String> lmap = new HashMap<String,String>();
					lmap.put(traces.get(m)[j][0], traces.get(m)[j][1]);
					treeFSM.lambda.put(treeFSM.curStateStr, lmap);
					
					treeFSM.curStateStr = nextStateStr;
				}
				else if ( treeFSM.lambda.get(treeFSM.curStateStr).get(traces.get(m)[j][0]) == null ){
					
					String nextStateStr = treeFSM.newState();
					(treeFSM.delta.get(treeFSM.curStateStr)).put(traces.get(m)[j][0], nextStateStr);
					(treeFSM.lambda.get(treeFSM.curStateStr)).put(traces.get(m)[j][0], traces.get(m)[j][1]);
					treeFSM.curStateStr = nextStateStr;
				}
				else {
					treeFSM.curStateStr = treeFSM.delta.get(treeFSM.curStateStr).get(traces.get(m)[j][0]);
				}
			}
		}
		
		return treeFSM;			
	}
	
	public static MealyFSM reduceFSM( MealyFSM fsm ){
		List<String> red = new ArrayList<String>();
		List<String> blue = new ArrayList<String>();
		
		red.add(fsm.initialStateStr);
		blue.addAll(fsm.stateMap.keySet());
		blue.remove(fsm.initialStateStr);
		
		while (!blue.isEmpty()){
			boolean isPromote = false;
			
			String stateB = blue.get(0);
			blue.remove(stateB);
			
			for (int i = 0; i<red.size() ;i++){
				String stateR = red.get(i);
				//check if the merge will break determinism
				
				if ( (fsm.delta.get(stateR) != null) && (fsm.delta.get(stateB) != null) ) 
				{
					
//				System.out.println("###");
//				System.out.println("stateR: "+stateR);
//				System.out.println("stateB: "+stateB);
//				System.out.println("###");
				
				for (String xR : fsm.delta.get(stateR).keySet()){
					for (String xB : fsm.delta.get(stateB).keySet()){
						String yR = fsm.lambda.get(stateR).get(xR);
						String yB = fsm.lambda.get(stateB).get(xB);
//						System.out.println("###");
//						System.out.println("xR: "+xR);
//						System.out.println("xB: "+xB);
//						System.out.println("yR: "+yR);
//						System.out.println("yB: "+yB);
//						System.out.println("###");
						
						//deterministic condition
						// if ((xR.equals(xB)) && (! yR.equals(yB) )){
						if ( xR.equals(xB) ){
							// promote stateB
							red.add(stateB);
							isPromote = true;
							// System.out.println("promote state: "+stateB);
							break;
						}
					}
					
					if (isPromote)
					{
						//System.out.println("promote break");
						break;
					}
				}
				}
				
				if (isPromote)
				{
					//System.out.println("promote break");
					break;
				}
				
				// merge state
				if (!isPromote){
					
					if ((fsm.delta.get(stateB) != null ) && (fsm.delta.get(stateR) != null)) 
					{
						for (String xB : fsm.delta.get(stateB).keySet()) {
							String stateBB = fsm.delta.get(stateB).get(xB);

							if (fsm.delta.get(stateR) == null) {
								System.out.println("null");
							}

							fsm.delta.get(stateR).put(xB, stateBB);

							//System.out.println("###");
							//System.out.println("stateR: "+stateR);
							//System.out.println("stateB: "+stateB);
							//System.out.println("stateBB: " + stateBB);
							//System.out.println("###");
						}
						if (!stateR.equals(stateB)) {
							fsm.delta.remove(stateB);
						}

						for (String xB : fsm.lambda.get(stateB).keySet()) {
							String yB = fsm.lambda.get(stateB).get(xB);
							fsm.lambda.get(stateR).put(xB, yB);
							// fsm.lambda.get(stateB).remove(xB);
						}
						if (!stateR.equals(stateB)) {
							// fsm.lambda.get(stateB).clear();
							fsm.lambda.remove(stateB);
						}
					}
					
					for (String stateP : fsm.delta.keySet()){
						if (fsm.delta.get(stateP) != null ){
						for (String xP : fsm.delta.get(stateP).keySet()){
//							System.out.println("###");
//							System.out.println("stateP: "+stateP);
//							System.out.println("stateR: "+stateR);
//							System.out.println("stateB: "+stateB);
//							System.out.println("stateXP: "+fsm.delta.get(stateP).get(xP));
//							System.out.println("###");
							if (fsm.delta.get(stateP).get(xP).equals(stateB)){
//								System.out.println("###");
//								System.out.println("stateP: "+stateP);
//								System.out.println("stateR: "+stateR);
//								System.out.println("stateB: "+stateB);
//								System.out.println("###");
								fsm.delta.get(stateP).put(xP, stateR);
							}
						}
						}
					}
				}
			}			
		}
		
		return fsm;
	}
	
	public static int editingDst (MealyFSM fsmA, MealyFSM fsmB)
	{
		int dst = 0;
		return dst;
	}

	// generate actual subset by index sequence
	public static ArrayList<String[][]> getSubset(ArrayList<String[][]> input, int[] subset) {
		ArrayList<String[][]> result = new ArrayList<String[][]>();
		//String[][][] result = input;
		
	    for (int i = 0; i < subset.length; i++) 
	    {
	    	//System.out.println("input.length="+input.size()+" subset[i]="+subset[i]+"result.length="+result.size());
	    	// result[i] = input[subset[i]];
	    	result.add(input.get(subset[i]));
	    }
	    return result;
	}
	
	public static ArrayList<ArrayList<String[][]>> getSubsets(ArrayList<String[][]> input, int k)
	{
		ArrayList<ArrayList<String[][]>> subsets = new ArrayList<ArrayList<String[][]>>();
		int[] s = new int[k];

		if (k <= input.size()) {
			// first index sequence: 0, 1, 2, ...
			for (int i = 0; i < k; i++)
			{
				s[i] = i;
			}
			
			subsets.add(getSubset(input, s));
			for(;;) {
				int i;
				// find position of item that can be incremented
				for (i = k - 1; i >= 0 && s[i] == input.size() - k + i; i--);
				
				if (i < 0) {
					break;
				}
				s[i]++;                    // increment this item
				for (++i; i < k; i++) {    // fill up remaining items
					s[i] = s[i - 1] + 1; 
				}
				subsets.add(getSubset(input, s));
			}
		}
		
		return subsets;
	}
	
	// generate actual subset by index sequence
	public static ArrayList<Integer> getIdSubset(ArrayList<Integer> input, int[] subset) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		
	    for (int i = 0; i < subset.length; i++) 
	    {
	    	//System.out.println("input.length="+input.size()+" subset[i]="+subset[i]+"result.length="+result.size());
	    	result.add(input.get(subset[i]));
	    }
	    return result;
	}
	
	public static ArrayList<ArrayList<Integer>> getIdSubsets(int arraySize, int k)
	{
		ArrayList<Integer> input = new ArrayList<Integer>(arraySize);
		for (int i = 0; i < arraySize; i++)
		{
			input.add(i);
		}
		
		ArrayList<ArrayList<Integer>> subsets = new ArrayList<ArrayList<Integer>>();
		int[] s = new int[k];

		if (k <= input.size()) {
			// first index sequence: 0, 1, 2, ...
			for (int i = 0; i < k; i++)
			{
				s[i] = i;
			}
			
			subsets.add(getIdSubset(input, s));
			for(;;) {
				int i;
				// find position of item that can be incremented
				for (i = k - 1; i >= 0 && s[i] == input.size() - k + i; i--);
				
				if (i < 0) {
					break;
				}
				s[i]++;                    // increment this item
				for (++i; i < k; i++) {    // fill up remaining items
					s[i] = s[i - 1] + 1; 
				}
				subsets.add(getIdSubset(input, s));
			}
		}
		
		return subsets;
	}
	
	public static BigInteger binomial(final int N, final int K) {
	    BigInteger ret = BigInteger.ONE;
	    for (int k = 0; k < K; k++) {
	        ret = ret.multiply(BigInteger.valueOf(N-k))
	                 .divide(BigInteger.valueOf(k+1));
	    }
	    return ret;
	}
	
	public static int fsmSize (MealyFSM fsm){
		int size = 0;		
		size = fsm.stateMap.size() + fsm.delta.size();
		return size;
	}
	
	public static void printFSM (MealyFSM fsm)
	{
		System.out.println("###");
		
		System.out.println("#states");
		for (String statestr : fsm.stateMap.keySet())
		{
			System.out.println(statestr);
		}
		
		System.out.println("#initial");
		System.out.println(fsm.initialStateStr);
		
		System.out.println("#accepting");
		System.out.println("#alphabet");
		for (String sstate : fsm.delta.keySet() ){
			for (String x : fsm.delta.get(sstate).keySet()){
				String dstate = fsm.delta.get(sstate).get(x);
				String y = fsm.lambda.get(sstate).get(x);
				System.out.println(""+x+"/"+y+"");
			}
		}
		
		System.out.println("#transitions");
		for (String sstate : fsm.delta.keySet() ){
			for (String x : fsm.delta.get(sstate).keySet()){
				String dstate = fsm.delta.get(sstate).get(x);
				String y = fsm.lambda.get(sstate).get(x);
				System.out.println(""+sstate+":"+x+"/"+y+">"+dstate);
			}
		}
		
		System.out.println("###");
	}
	
	public static void RANSECModelAccurancy (ArrayList<String[][]> tracesAll)
	{
	    int n = 50;
	    int k = 10000;
	    int runNum = 100;
	    int minSize = 6;
		// ArrayList<String[][][]> kSubsets = new ArrayList<String[][][]>();
		// ArrayList<ArrayList<String[][]>> kSubsets = new ArrayList<ArrayList<String[][]>>();
		// kSubsets = getSubsets(tracesAll, n);
	    ArrayList<ArrayList<Integer>> kSubsets = new ArrayList<ArrayList<Integer>>();
	    System.out.println("tracesAll.size = " + tracesAll.size());
	    int combNum = binomial(tracesAll.size(),n).intValue();
	    // System.out.println("combination = " + binomial(tracesAll.size(),n));
	    System.out.println("combination = " + combNum);
		// kSubsets = getIdSubsets(tracesAll.size(), n);	
		
		int hitNum = 0;
		int smallerNum = 0;
		int largerNum = 0;
		for (int j = 0; j < runNum; j++){
			
		for (int i = 0; i < k; i++){
		
			// TODO: this approach can generate dup rand numbers
			Random randomno = new Random();
			int trace_num = randomno.nextInt(combNum);
			
			ArrayList<String[][]> traces = new ArrayList<String[][]>();
			
			for (int id = 0; id < n; id++){
				Random rand = new Random();
				int rand_id = randomno.nextInt(tracesAll.size()-1);
				traces.add(tracesAll.get(rand_id));
			}
			
			/*
			ArrayList<Integer> tracesId = kSubsets.get(trace_num);	
			for (int id : tracesId)
			{
				traces.add(tracesAll.get(id));
			}
			*/
			
			// build tree fsm
			MealyFSM treeFSM = buildTreeFSM( traces );
			// printFSM(treeFSM);
		
			// reduce fsm
			MealyFSM resultFSM = reduceFSM(treeFSM);
			// printFSM(resultFSM);
		
			int size = fsmSize(resultFSM);
			// System.out.println("size = "+size);
			
			if (size == minSize)
			{
				hitNum = hitNum + 1;
				break;
			}
			else if (size < minSize)
			{
				smallerNum = smallerNum + 1;
				continue;
			}
			else{}
			
		}
		
		}
		System.out.println("hitNum = " + hitNum);
		System.out.println("smallerNum = " + smallerNum);
		// System.out.println("largerNum = " + largerNum);
	
	}
	
	public static MealyFSM RANSEC(ArrayList<String[][]> tracesAll) {
		// input
		int traceNum = tracesAll.size();

		// output
		MealyFSM benignFSM = new MealyFSM();

		// default 50
		int n = 7;
		int k = 10000;
		int runNum = 1;

		ArrayList<ArrayList<Integer>> kSubsets = new ArrayList<ArrayList<Integer>>();
		System.out.println("tracesAll.size = " + tracesAll.size());
		int combNum = binomial(tracesAll.size(), n).intValue();
		// System.out.println("combination = " + binomial(tracesAll.size(),n));
		System.out.println("combination = " + combNum);
		// kSubsets = getIdSubsets(tracesAll.size(), n);

		int minSize = 30000;

		for (int j = 0; j < runNum; j++) {
			for (int i = 0; i < k; i++) {

				// TODO: this approach can generate dup rand numbers
				Random randomno = new Random();
				ArrayList<String[][]> traces = new ArrayList<String[][]>();

				for (int id = 0; id < n; id++) {
					Random rand = new Random();
					int rand_id = randomno.nextInt(tracesAll.size() - 1);
					traces.add(tracesAll.get(rand_id));
				}

				// build tree fsm
				MealyFSM treeFSM = buildTreeFSM(traces);
				// printFSM(treeFSM);

				// reduce fsm
				MealyFSM resultFSM = reduceFSM(treeFSM);
				// printFSM(resultFSM);

				int size = fsmSize(resultFSM);
				// System.out.println("size = "+size);

				if (size < minSize) {
					minSize = size;
					benignFSM = resultFSM;
				}

			}

		}
		System.out.println("minSize = " + minSize);
		return benignFSM;
	}
	
	public static int[] FSMTranverse(MealyFSM fsm, ArrayList<String[][]> tracesAll){
		int traceNum = tracesAll.size();
		int[] assignments = new int[traceNum];
		
		for (int i = 0; i < traceNum; i++) {
			String[][] trace = tracesAll.get(i);

			// set current state to 0
			fsm.resetState();			
			
			for (int j = 0; j < trace.length; j++)
			{
				String iStr = trace[j][0];
				String oStr = trace[j][1];
				
				boolean isMatch =  fsm.tranverse(iStr, oStr);
				
				if (isMatch == false)
				{
					assignments[i] = 1;
					break;
				}
			}
		}
		
		return assignments;
	}
	
	public static int editDistance(String word1, String word2) {
		int len1 = word1.length();
		int len2 = word2.length();
	 
		// len1+1, len2+1, because finally return dp[len1][len2]
		int[][] dp = new int[len1 + 1][len2 + 1];
	 
		for (int i = 0; i <= len1; i++) {
			dp[i][0] = i;
		}
	 
		for (int j = 0; j <= len2; j++) {
			dp[0][j] = j;
		}
	 
		//iterate though, and check last char
		for (int i = 0; i < len1; i++) {
			char c1 = word1.charAt(i);
			for (int j = 0; j < len2; j++) {
				char c2 = word2.charAt(j);
	 
				//if last two chars equal
				if (c1 == c2) {
					//update dp value for +1 length
					dp[i + 1][j + 1] = dp[i][j];
				} else {
					int replace = dp[i][j] + 1;
					int insert = dp[i][j + 1] + 1;
					int delete = dp[i + 1][j] + 1;
	 
					int min = replace > insert ? insert : replace;
					min = delete > min ? min : delete;
					dp[i + 1][j + 1] = min;
				}
			}
		}
	 
		return dp[len1][len2];
	}
	
	/*
	 * edit distance of string array
	 * */
	public static int editDistance(String[] word1, String[] word2) {
		int len1 = word1.length;
		int len2 = word2.length;
	 
		// len1+1, len2+1, because finally return dp[len1][len2]
		int[][] dp = new int[len1 + 1][len2 + 1];
	 
		for (int i = 0; i <= len1; i++) {
			dp[i][0] = i;
		}
	 
		for (int j = 0; j <= len2; j++) {
			dp[0][j] = j;
		}
	 
		//iterate though, and check last char
		for (int i = 0; i < len1; i++) {
			String c1 = word1[i];
			for (int j = 0; j < len2; j++) {
				String c2 = word2[j];
	 
				//if last two chars equal
				if (c1.equals(c2)) {
					//update dp value for +1 length
					dp[i + 1][j + 1] = dp[i][j];
				} else {
					int replace = dp[i][j] + 1;
					int insert = dp[i][j + 1] + 1;
					int delete = dp[i + 1][j] + 1;
	 
					int min = replace > insert ? insert : replace;
					min = delete > min ? min : delete;
					dp[i + 1][j + 1] = min;
				}
			}
		}
	 
		return dp[len1][len2];
	}
	
	public static class TraceData {
		ArrayList<String[][]> tracesAll;
		int[] labels;
		
		TraceData(ArrayList<String[][]> tracesAll, int[] labels){
			this.tracesAll = tracesAll;
			this.labels = labels;
		}
	}
	
	public static TraceData generateCSV() throws IOException{
		
		// String[][][] tracesTest = { { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"}, {"6","6"}, {"6","10"} }, { {"1", "1"}, {"1", "2"}, {"2", "3"}, {"2", "4"}, {"3", "5"}, {"3", "10"} } };
		
				/* Router Telnet */
				// cmp-dos
				// String[][] tracesCmpDoS = { {"1", "1"}, {"1", "2"}, {"2", "3"}, {"2", "4"}, {"3", "5"}, {"3", "10"} } ;
				String[][] tracesA1 = { {"1", "1"}, {"1", "2"}, {"2", "3"}, {"2", "4"}, {"3", "5"}, {"3", "10"} } ;
				String[][] tracesA2 = { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1", "1"}, {"1", "2"}, {"2", "3"}, {"2", "4"}, {"3", "5"}, {"3", "10"} } ;
				String[][] tracesA3 = { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1", "1"}, {"1", "2"}, {"2", "3"}, {"2", "4"}, {"6","3"}, {"6","10"}, {"3", "5"}, {"3", "10"} } ;
				String[][] tracesA4 = { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1", "1"}, {"1", "2"}, {"2", "3"}, {"2", "4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"}, {"3", "5"}, {"3", "10"} } ;
				String[][] tracesA5 = { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1", "1"}, {"1", "2"}, {"2", "3"}, {"2", "4"}, {"6","3"}, {"6","10"}, {"6","3"}, {"6","10"}, {"3", "5"}, {"3", "10"} } ;
			    
				// cmp trace 1: login
				// String[][] traces1 = { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"} } ;
				String[][] traces1 = { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"} } ;
				// cmp trace 2: enable
				// String[][] traces2 =  { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"}, {"6","6"}, {"6","10"} } ;
				String[][] traces2 =  { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"}, {"6","6"}, {"6","10"} } ;
				// cmp trace 3: enable2
				String[][] traces3 =  { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"}, {"6","6"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"} } ;
				// cmp trace 4: login2
				String[][] traces4 =  { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"} } ;
				// cmp trace 5: traceroute
				String[][] traces5 =  { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"} } ;
				
				// cmp trace 1: login3
				String[][] traces6 =  { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"} } ;
				// cmp trace 2: enable3
				String[][] traces7 =  { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"}, {"6","6"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"}, {"6","6"}, {"6","10"} } ;
				// cmp trace 3: enable4
				String[][] traces8 =  { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"}, {"6","6"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"} } ;
				// cmp trace 4: login4
				String[][] traces9 =  { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"} } ;
				// cmp trace 5: traceroute2
				String[][] traces10 =  { {"4","2"}, {"5","3"}, {"5","4"}, {"5","6"}, {"5","7"}, {"5","8"}, {"4","9"}, {"1","1"}, {"1","2"}, {"2","3"}, {"2","4"}, {"6","3"}, {"6","10"}, {"2","6"}, {"6","6"}, {"6","10"}  };
				
				/* Router Http */
				/*
				String[][] tracesA1 = { {"1", "2"}, {"1", "2"}, {"1", "2"}} ;
				String[][] tracesA2 = { {"1", "2"}, {"2", "2"}} ;
				String[][] tracesA3 = { {"1", "2"}, {"1", "2"}} ;
				String[][] tracesA4 = { {"1", "2"}, {"2", "2"}, {"2", "2"}} ;
				String[][] tracesA5 = { {"1", "2"}, {"1", "2"}, {"2", "2"}} ;
				
				// cmp trace 1: login
				String[][] traces1 =  { {"1","1"}, {"1","2"}} ;
				// cmp trace 2: enable
				String[][] traces2 =  { {"1","1"}, {"2","2"}} ;
				// cmp trace 3: enable2
				String[][] traces3 =  { {"1","1"}, {"1","2"}, {"1","2"}} ;
				// cmp trace 4: login2
				String[][] traces4 =  { {"1","1"}, {"1","2"}, {"2","2"}} ;
				// cmp trace 5: traceroute
				String[][] traces5 =  { {"1","1"}, {"2","2"}, {"1","2"}};
				// cmp trace 1: login3
				String[][] traces6 =  { {"1","1"}, {"2","2"}, {"2","2"}} ;
				// cmp trace 2: enable3
				String[][] traces7 =  { {"1","1"}, {"1","2"}, {"1","2"}, {"1","2"}, {"1","2"}, {"1","2"}, {"1","2"}} ;
				// cmp trace 3: enable4
				String[][] traces8 =  { {"1","1"}, {"1","2"}, {"2","2"}, {"2","2"}};
				// cmp trace 4: login4
				String[][] traces9 =  { {"1","1"}, {"1","2"}, {"2","2"}, {"2","2"}};
				// cmp trace 5: traceroute2
				String[][] traces10 =  { {"1","1"}, {"1","2"}, {"1","2"}, {"1","2"}};
				*/
				
				// Mix traces
				ArrayList<String[][]> tracesAll = new ArrayList<String[][]>();
				// Max trace length
				int maxLen = 0;
				
				// generate 10/100 traces
				for (int i = 0; i < 100; i++){
				tracesAll.add(traces1);
				tracesAll.add(traces2);
				tracesAll.add(traces3);
				tracesAll.add(traces4);
				tracesAll.add(traces5);
				tracesAll.add(traces6);
				tracesAll.add(traces7);
				tracesAll.add(traces8);
				tracesAll.add(traces9);
				tracesAll.add(traces10);
				}
				
				// add labels after tracesAll are created
				int[] labels = new int[tracesAll.size()];
				
				for (int i = 0; i < 20; i++){
					tracesAll.set(50*i+5, tracesA1);
					tracesAll.set(50*i+15, tracesA2);
					tracesAll.set(50*i+25, tracesA3);
					tracesAll.set(50*i+35, tracesA4);
					tracesAll.set(50*i+45, tracesA5);
					
					labels[50*i+5] = 1;
					labels[50*i+15] = 1;
					labels[50*i+25] = 1;
					labels[50*i+35] = 1;
					labels[50*i+45] = 1;
				}
				
				// record max trace length
				for (int i = 0; i < 50; i++){
					if (tracesAll.get(i).length * 2 > maxLen) {
						maxLen = tracesAll.get(i).length * 2;
					}
				}
				
				/*
				for (int i = 0; i < 50; i++){
					tracesAll.set(20*i+5, tracesA1);
					tracesAll.set(20*i+15, tracesA2);
					
					labels[20*i+5] = 1;
					labels[20*i+15] = 1;
				}
				*/
				
				/*
				for (int i = 0; i < 150; i++){
					tracesAll.set(6*i+3, tracesA1);
					
					// set the labels
					labels[6*i+3] = 1;
				}
				*/

				/*
				for (int i = 0; i < 100; i++){
					tracesAll.set(10*i+5, tracesA1);
				}
				*/
				
				/*
				for (int i = 0; i < 50; i++){
					tracesAll.set(20*i+5, tracesA1);
				}	
				*/
				
				/*
				for (int i = 0; i < 10; i++){
					tracesAll.set(100*i+5, tracesA1);
				}
				*/
				
				// output to csv file
				// message series csv
				FileWriter writer = new FileWriter("ms.csv");
				// for (int i=0; i< tracesAll.size(); i++ ){
				for (int i=0; i< maxLen; i++ ){
					writer.append(""+i);
					writer.append(',');
				}
				writer.append(""+maxLen);
				writer.append('\n');
				
				for (int i=0; i< tracesAll.size(); i++ ){
					// System.out.println("tracesAll size = " + i);
					for (int j=0; j< tracesAll.get(i).length; j++ ){
						String si = tracesAll.get(i)[j][0];
						String so = tracesAll.get(i)[j][1];
						
						writer.append(si);
						writer.append(',');
						writer.append(so);
						writer.append(',');
					}
					for (int j=(tracesAll.get(i).length)*2; j<maxLen; j++ ){
						writer.append(""+1);
						writer.append(',');
					}
					writer.append(""+1);
					writer.append('\n');
				}
				writer.flush();
				
				// ngram csv
				
				// editing distance csv
				writer = new FileWriter("editDistance.csv");
				// features
				int tracesNum = tracesAll.size();
				for (int i=0; i< tracesNum - 1; i++ ){
					writer.append(""+i);
					writer.append(',');
				}
				writer.append(""+ (tracesNum-1) );
				writer.append('\n');
				writer.flush();
				
				for (int i=0; i< tracesNum; i++ ){
					for (int j=0; j< tracesNum; j++ ){
						if (i != j){
							// calculate the edit distance of two instances
							String[] sa = Utils.twoArray2Array(tracesAll.get(i));
							String[] sb = Utils.twoArray2Array(tracesAll.get(j));
							int ed = editDistance(sa, sb);
							
							// output to csv
							writer.append(""+ed);
							writer.append(',');
						}				
					}
					writer.append(""+ 0 );
					writer.append('\n');
				}
				writer.flush();
				
				// TraceData traceData = new TraceData(tracesAll, labels);
				// traceData.labels = labels;
				// traceData.tracesAll = tracesAll;
				return new TraceData(tracesAll, labels);
	}
	
	public static void metrics (int[] labels, int[] assignments){
		int total = labels.length;
		int fp = 0;
		int fn = 0;
		int tp = 0;
		int tn = 0;
		float fpr = 0;
		float tpr = 0;
		// ROC 
		for (int i=0; i < total; i++ ){
				// FP: 0 in labels, 1 in assignments
				if ( (labels[i] == 0 ) && (assignments[i] == 1) ) {
					fp ++;
				}
				// FN: 1 in labels, 0 in assignments
				if ( (labels[i] == 1 ) && (assignments[i] == 0) ) {
					fn ++;
				}
				// TP: 1 in labels, 1 in assignments
				if ( (labels[i] == 1 ) && (assignments[i] == 1) ) {
					tp ++;
				}
				// TN: 0 in labels, 0 in assignments
				if ( (labels[i] == 0 ) && (assignments[i] == 0) ) {
					tn ++;
				}
		}
		
		// fpr
		fpr = ((float) fp)/(fp + tn);
		// tpr
		tpr = ((float) tp)/(tp + fn);
		System.out.printf("fp = %d \n", fp );
		System.out.printf("tp = %d \n", tp );
		System.out.printf("fn = %d \n", fn );
		System.out.printf("tn = %d \n", tn );
		System.out.printf("fpr = %f \n", fpr );
		System.out.printf("tpr = %f \n", tpr );
	}
	
	public static void main(String[] args) throws Exception{
		System.out.println("main");			
		
		TraceData traceData = generateCSV();
		int[] labels = traceData.labels;
		ArrayList<String[][]> tracesAll = traceData.tracesAll;
		
		// 1. Our approach
		/*
		MealyFSM benignFSM = RANSEC(tracesAll);
		// printFSM(benignFSM);
		int[] assignments = FSMTranverse(benignFSM, tracesAll);
		*/
		
		// 2. Kmeans + editing distance
		/*
		Cluster cluster = new Cluster();
		int[] assignments  = cluster.SimpleKMeansFunc("editDistance.csv");
		// wait for the task to complete TODO: try remove
		// Thread.sleep(2000);
		*/
		
		// 3. Kmeans + ngram
		/*
		Cluster cluster = new Cluster();
		int[] assignments  = cluster.SimpleKMeansFunc("ms.csv");
		// wait for the task to complete TODO: try remove
		// Thread.sleep(2000);
		*/
		
		// 4. hierachical clustering
		Cluster cluster = new Cluster();
		int[] assignments = cluster.HierarchicalClusterer("editDistance.csv");
		
		// measure fp fn
		metrics(labels, assignments);
	}

}
